#line 1 "C:/Users/daria/Downloads/Leds_Multiples/NUEVO AHORA SI/DISPLAY02.c"
void main() {

 TRISB = 0x00;
 PORTB = 0x00;

 while(1) {

 PORTB = 0x3F;
 Delay_ms(1000);

 PORTB = 0x06;
 Delay_ms(1000);

 PORTB = 0x5B;
 Delay_ms(1000);

 PORTB = 0x4F;
 Delay_ms(1000);

 PORTB = 0x66;
 Delay_ms(1000);

 PORTB = 0x6D;
 Delay_ms(1000);

 PORTB = 0x7D;
 Delay_ms(1000);

 PORTB = 0x07;
 Delay_ms(1000);

 PORTB = 0x7F;
 Delay_ms(1000);

 PORTB = 0x6F;
 Delay_ms(1000);

 PORTB = 0x77;
 Delay_ms(1000);

 PORTB = 0x7C;
 Delay_ms(1000);

 PORTB = 0x39;
 Delay_ms(1000);

 PORTB = 0x5E;
 Delay_ms(1000);

 PORTB = 0x79;
 Delay_ms(1000);

 PORTB = 0x71;
 Delay_ms(1000);
 }
}
