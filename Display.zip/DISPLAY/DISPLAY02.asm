
_main:

;DISPLAY02.c,1 :: 		void main() {
;DISPLAY02.c,3 :: 		TRISB = 0x00;      // PORTB como salida
	CLRF       TRISB+0
;DISPLAY02.c,4 :: 		PORTB = 0x00;      // Apagar todos los segmentos al inicio
	CLRF       PORTB+0
;DISPLAY02.c,6 :: 		while(1) {
L_main0:
;DISPLAY02.c,8 :: 		PORTB = 0x3F;  // 0
	MOVLW      63
	MOVWF      PORTB+0
;DISPLAY02.c,9 :: 		Delay_ms(1000);
	MOVLW      26
	MOVWF      R11+0
	MOVLW      94
	MOVWF      R12+0
	MOVLW      110
	MOVWF      R13+0
L_main2:
	DECFSZ     R13+0, 1
	GOTO       L_main2
	DECFSZ     R12+0, 1
	GOTO       L_main2
	DECFSZ     R11+0, 1
	GOTO       L_main2
	NOP
;DISPLAY02.c,11 :: 		PORTB = 0x06;  // 1
	MOVLW      6
	MOVWF      PORTB+0
;DISPLAY02.c,12 :: 		Delay_ms(1000);
	MOVLW      26
	MOVWF      R11+0
	MOVLW      94
	MOVWF      R12+0
	MOVLW      110
	MOVWF      R13+0
L_main3:
	DECFSZ     R13+0, 1
	GOTO       L_main3
	DECFSZ     R12+0, 1
	GOTO       L_main3
	DECFSZ     R11+0, 1
	GOTO       L_main3
	NOP
;DISPLAY02.c,14 :: 		PORTB = 0x5B;  // 2
	MOVLW      91
	MOVWF      PORTB+0
;DISPLAY02.c,15 :: 		Delay_ms(1000);
	MOVLW      26
	MOVWF      R11+0
	MOVLW      94
	MOVWF      R12+0
	MOVLW      110
	MOVWF      R13+0
L_main4:
	DECFSZ     R13+0, 1
	GOTO       L_main4
	DECFSZ     R12+0, 1
	GOTO       L_main4
	DECFSZ     R11+0, 1
	GOTO       L_main4
	NOP
;DISPLAY02.c,17 :: 		PORTB = 0x4F;  // 3
	MOVLW      79
	MOVWF      PORTB+0
;DISPLAY02.c,18 :: 		Delay_ms(1000);
	MOVLW      26
	MOVWF      R11+0
	MOVLW      94
	MOVWF      R12+0
	MOVLW      110
	MOVWF      R13+0
L_main5:
	DECFSZ     R13+0, 1
	GOTO       L_main5
	DECFSZ     R12+0, 1
	GOTO       L_main5
	DECFSZ     R11+0, 1
	GOTO       L_main5
	NOP
;DISPLAY02.c,20 :: 		PORTB = 0x66;  // 4
	MOVLW      102
	MOVWF      PORTB+0
;DISPLAY02.c,21 :: 		Delay_ms(1000);
	MOVLW      26
	MOVWF      R11+0
	MOVLW      94
	MOVWF      R12+0
	MOVLW      110
	MOVWF      R13+0
L_main6:
	DECFSZ     R13+0, 1
	GOTO       L_main6
	DECFSZ     R12+0, 1
	GOTO       L_main6
	DECFSZ     R11+0, 1
	GOTO       L_main6
	NOP
;DISPLAY02.c,23 :: 		PORTB = 0x6D;  // 5
	MOVLW      109
	MOVWF      PORTB+0
;DISPLAY02.c,24 :: 		Delay_ms(1000);
	MOVLW      26
	MOVWF      R11+0
	MOVLW      94
	MOVWF      R12+0
	MOVLW      110
	MOVWF      R13+0
L_main7:
	DECFSZ     R13+0, 1
	GOTO       L_main7
	DECFSZ     R12+0, 1
	GOTO       L_main7
	DECFSZ     R11+0, 1
	GOTO       L_main7
	NOP
;DISPLAY02.c,26 :: 		PORTB = 0x7D;  // 6
	MOVLW      125
	MOVWF      PORTB+0
;DISPLAY02.c,27 :: 		Delay_ms(1000);
	MOVLW      26
	MOVWF      R11+0
	MOVLW      94
	MOVWF      R12+0
	MOVLW      110
	MOVWF      R13+0
L_main8:
	DECFSZ     R13+0, 1
	GOTO       L_main8
	DECFSZ     R12+0, 1
	GOTO       L_main8
	DECFSZ     R11+0, 1
	GOTO       L_main8
	NOP
;DISPLAY02.c,29 :: 		PORTB = 0x07;  // 7
	MOVLW      7
	MOVWF      PORTB+0
;DISPLAY02.c,30 :: 		Delay_ms(1000);
	MOVLW      26
	MOVWF      R11+0
	MOVLW      94
	MOVWF      R12+0
	MOVLW      110
	MOVWF      R13+0
L_main9:
	DECFSZ     R13+0, 1
	GOTO       L_main9
	DECFSZ     R12+0, 1
	GOTO       L_main9
	DECFSZ     R11+0, 1
	GOTO       L_main9
	NOP
;DISPLAY02.c,32 :: 		PORTB = 0x7F;  // 8
	MOVLW      127
	MOVWF      PORTB+0
;DISPLAY02.c,33 :: 		Delay_ms(1000);
	MOVLW      26
	MOVWF      R11+0
	MOVLW      94
	MOVWF      R12+0
	MOVLW      110
	MOVWF      R13+0
L_main10:
	DECFSZ     R13+0, 1
	GOTO       L_main10
	DECFSZ     R12+0, 1
	GOTO       L_main10
	DECFSZ     R11+0, 1
	GOTO       L_main10
	NOP
;DISPLAY02.c,35 :: 		PORTB = 0x6F;  // 9
	MOVLW      111
	MOVWF      PORTB+0
;DISPLAY02.c,36 :: 		Delay_ms(1000);
	MOVLW      26
	MOVWF      R11+0
	MOVLW      94
	MOVWF      R12+0
	MOVLW      110
	MOVWF      R13+0
L_main11:
	DECFSZ     R13+0, 1
	GOTO       L_main11
	DECFSZ     R12+0, 1
	GOTO       L_main11
	DECFSZ     R11+0, 1
	GOTO       L_main11
	NOP
;DISPLAY02.c,38 :: 		PORTB = 0x77;  // A
	MOVLW      119
	MOVWF      PORTB+0
;DISPLAY02.c,39 :: 		Delay_ms(1000);
	MOVLW      26
	MOVWF      R11+0
	MOVLW      94
	MOVWF      R12+0
	MOVLW      110
	MOVWF      R13+0
L_main12:
	DECFSZ     R13+0, 1
	GOTO       L_main12
	DECFSZ     R12+0, 1
	GOTO       L_main12
	DECFSZ     R11+0, 1
	GOTO       L_main12
	NOP
;DISPLAY02.c,41 :: 		PORTB = 0x7C;  // b
	MOVLW      124
	MOVWF      PORTB+0
;DISPLAY02.c,42 :: 		Delay_ms(1000);
	MOVLW      26
	MOVWF      R11+0
	MOVLW      94
	MOVWF      R12+0
	MOVLW      110
	MOVWF      R13+0
L_main13:
	DECFSZ     R13+0, 1
	GOTO       L_main13
	DECFSZ     R12+0, 1
	GOTO       L_main13
	DECFSZ     R11+0, 1
	GOTO       L_main13
	NOP
;DISPLAY02.c,44 :: 		PORTB = 0x39;  // C
	MOVLW      57
	MOVWF      PORTB+0
;DISPLAY02.c,45 :: 		Delay_ms(1000);
	MOVLW      26
	MOVWF      R11+0
	MOVLW      94
	MOVWF      R12+0
	MOVLW      110
	MOVWF      R13+0
L_main14:
	DECFSZ     R13+0, 1
	GOTO       L_main14
	DECFSZ     R12+0, 1
	GOTO       L_main14
	DECFSZ     R11+0, 1
	GOTO       L_main14
	NOP
;DISPLAY02.c,47 :: 		PORTB = 0x5E;  // d
	MOVLW      94
	MOVWF      PORTB+0
;DISPLAY02.c,48 :: 		Delay_ms(1000);
	MOVLW      26
	MOVWF      R11+0
	MOVLW      94
	MOVWF      R12+0
	MOVLW      110
	MOVWF      R13+0
L_main15:
	DECFSZ     R13+0, 1
	GOTO       L_main15
	DECFSZ     R12+0, 1
	GOTO       L_main15
	DECFSZ     R11+0, 1
	GOTO       L_main15
	NOP
;DISPLAY02.c,50 :: 		PORTB = 0x79;  // E
	MOVLW      121
	MOVWF      PORTB+0
;DISPLAY02.c,51 :: 		Delay_ms(1000);
	MOVLW      26
	MOVWF      R11+0
	MOVLW      94
	MOVWF      R12+0
	MOVLW      110
	MOVWF      R13+0
L_main16:
	DECFSZ     R13+0, 1
	GOTO       L_main16
	DECFSZ     R12+0, 1
	GOTO       L_main16
	DECFSZ     R11+0, 1
	GOTO       L_main16
	NOP
;DISPLAY02.c,53 :: 		PORTB = 0x71;  // F
	MOVLW      113
	MOVWF      PORTB+0
;DISPLAY02.c,54 :: 		Delay_ms(1000);
	MOVLW      26
	MOVWF      R11+0
	MOVLW      94
	MOVWF      R12+0
	MOVLW      110
	MOVWF      R13+0
L_main17:
	DECFSZ     R13+0, 1
	GOTO       L_main17
	DECFSZ     R12+0, 1
	GOTO       L_main17
	DECFSZ     R11+0, 1
	GOTO       L_main17
	NOP
;DISPLAY02.c,55 :: 		}
	GOTO       L_main0
;DISPLAY02.c,56 :: 		}
L_end_main:
	GOTO       $+0
; end of _main
